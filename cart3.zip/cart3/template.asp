<~
include "common.shh"
include "build_session.shh"

function fragment(input)
include input
end function

function pagestate(qstring)

'here we go figuring out the page states

state = q("state")

if state = "cart" then
fragment("cart.asp")

elseif state = "category" then
fragment("products.shh")

elseif state = "all" then
fragment("all.shh")

elseif state = "productlist" then
fragment("productlist.shh")

elseif state = "product" then
fragment("product.shh")

elseif state = "search" then
fragment("search.asp")


end if


end function


~>


<html>
<head>
<title><~@Getcookie("title")~></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<table border="0" cellpadding="2">
  <tr>
    <td colspan="2"><h3><~@GetCookie("title")~> | <~@GetCookie("sc")~> |  <~@GetCookie("pc")~> 
    </h3></td>
  </tr>
  <tr>
    <td colspan="2"><table><form name="form1" method="post" action="<~@script~>?state=search"><tr>
  <td>Keyword Search 
  </td>
  <td><input name="ibox" type="text" id="ibox2" value="<~@ibox~>"></td>
  <td><input type="submit" name="Submit" value="Search"></td>
    </tr></form>
</table>
</td>
  </tr>
  <tr valign="top">
    <td><~fragment("categories_nav.asp")~></td>
    <td><~pagestate()~></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
</body>
</html>
