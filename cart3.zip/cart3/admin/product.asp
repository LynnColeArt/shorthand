<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<form name="form1" method="post" action="">
  <table width="100%"  border="0" cellspacing="4" cellpadding="0">
    <tr>
      <td colspan="2">Edit Screen </td>
    </tr>
    <tr>
      <td>CategoryId</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="21%">Modelname</td>
      <td width="79%">&nbsp;</td>
    </tr>
    <tr>
      <td>Unitcost</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>ProductImage URL </td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>Modelnumber </td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>Entry is </td>
      <td>New Product X Update X </td>
    </tr>
    <tr>
      <td colspan="2"><input type="submit" name="Submit" value="Submit"></td>
    </tr>
  </table>
</form>
</body>
</html>
