<~
include "../config.tran"

function fragment(input)
include input
end function

function pagestate(qstring)

'here we go figuring out the page states

state = q("state")

if state = "categories" or state = null then
fragment("categories_nav.tran")

elseif state = "category" then
fragment("category.tran")

elseif state = "all" then
fragment("all.tran")

elseif state = "productlist" then
fragment("productlist.tran")

elseif state = "product" then
fragment("product.tran")

elseif state = "newproduct" then
fragment("product.new.tran")


end if


end function


~>


<html>
<head>
<title><~@Getcookie("title")~></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<table border="0" cellpadding="2">
  <tr>
    <td><h3><~@GetCookie("title")~> 
    </h3></td>
  </tr>
  <tr>
    <td><table><form name="form1" method="post" action="<~@script~>?state=search"><tr>
  <td>Keyword Search 
  </td>
  <td><input name="ibox" type="text" id="ibox2" value="<~@ibox~>"></td>
  <td><input type="submit" name="Submit" value="Search"></td>
    </tr></form>
</table>
</td>
  </tr>
  <tr valign="top">
    <td>&nbsp;</td>
  </tr>
  <tr valign="top">
    <td><~pagestate()~></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
<~Exit()~>
